// dashboard.js
async function fetchDashboardStats() {
  const { data: employees } = await supabase.from('employees').select('*');
  const { data: attendance } = await supabase.from('attendance').select('*').eq('date', today);
  const { data: leaves } = await supabase.from('leaves').select('*').eq('status', 'pending');
  updateDashboardUI(employees, attendance, leaves);
}