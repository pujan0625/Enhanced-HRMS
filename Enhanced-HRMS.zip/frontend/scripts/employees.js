// employees.js
async function addEmployee(employeeData) {
  const { data, error } = await supabase.from('employees').insert([employeeData]);
  if (error) throw error; return data;
}
async function updateEmployee(id, updates) {
  const { data, error } = await supabase.from('employees').update(updates).eq('id', id);
  if (error) throw error; return data;
}