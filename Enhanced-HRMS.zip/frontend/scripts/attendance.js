// attendance.js
async function clockIn(employeeId) {
  const { data, error } = await supabase.from('attendance').insert([{
    employee_id: employeeId,
    check_in: new Date().toISOString(),
    date: new Date().toISOString().split('T')[0],
    status: 'present'
  }]);
}