-- employees table
CREATE TABLE employees (...);
-- attendance table
CREATE TABLE attendance (...);
-- departments table
CREATE TABLE departments (...);
-- leaves table
CREATE TABLE leaves (...);